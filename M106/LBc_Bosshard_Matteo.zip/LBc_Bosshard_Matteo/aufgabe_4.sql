UPDATE customer 
SET first_name = 'JOHN', last_name = 'DOE' 
WHERE customer_id = 359;