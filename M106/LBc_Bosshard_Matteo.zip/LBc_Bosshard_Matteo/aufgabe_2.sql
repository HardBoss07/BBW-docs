ALTER TABLE actor 
ADD gender ENUM('male','female','others') NULL;
