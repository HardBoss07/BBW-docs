DELETE FROM film_category WHERE category_id = 10;
DELETE FROM category WHERE category_id = 10;
