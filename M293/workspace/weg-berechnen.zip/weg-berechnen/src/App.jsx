import bild from './assets/img.png'
import './App.css'
import FormComponent from "./components/Form Component.jsx";

function App() {

  return (
    <>
        <h1>Weg berechnen</h1>
        <img src={bild} />
        <FormComponent/>
    </>
  )
}

export default App
